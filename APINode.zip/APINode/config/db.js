const mongoose = require('mongoose');

module.exports = {
    'secret':'nodeauthsecret',
    'database' :  mongoose.connect('srv', { useNewUrlParser: true }, (err) => {

    if (!err) { console.log('MongoDB Connection Succeeded.') }
    else { console.log('Error in DB connection : ' + err) }
})};
require("../models/Person");
require("../models/Article");
require("../models/User");
require("../models/Book");
